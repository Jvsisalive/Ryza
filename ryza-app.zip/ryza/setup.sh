#!/bin/bash
# Needs: Node 18+, JDK 17, Android SDK (ANDROID_HOME set)
set -e
npm install
[ -d android ] || npx cap add android
D=android/app/src/main/java/com/ryza/app
mkdir -p $D && cp native/*.java $D/
python3 - <<'PY'
p="android/app/src/main/AndroidManifest.xml"
s=open(p).read()
if "ryza-patched" not in s:
    s=s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android"','<manifest xmlns:android="http://schemas.android.com/apk/res/android" xmlns:tools="http://schemas.android.com/tools"',1)
    add='''<!-- ryza-patched -->
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.FLASHLIGHT"/>
    <uses-permission android:name="android.permission.SET_ALARM"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" tools:ignore="ProtectedPermissions"/>
    <queries><intent><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent></queries>
    '''
    s=s.replace("<application",add+"<application",1)
    open(p,"w").write(s)
s=open(p).read()
if "ryza-bg" not in s:
    perms='''<!-- ryza-bg -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>
    '''
    comps='''<service android:name=".ScoldService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="screen time reminders"/>
        </service>
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/></intent-filter>
        </receiver>
    '''
    s=s.replace("<application",perms+"<application",1).replace("</application>",comps+"</application>",1)
    open(p,"w").write(s)
PY
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
echo "DONE. APK: android/app/build/outputs/apk/debug/app-debug.apk"
