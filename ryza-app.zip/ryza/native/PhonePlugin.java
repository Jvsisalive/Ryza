package com.ryza.app;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.AlarmClock;
import android.provider.Settings;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import androidx.core.content.ContextCompat;

@CapacitorPlugin(name = "Phone")
public class PhonePlugin extends Plugin {

  private void go(Intent i) { getActivity().startActivity(i); }

  @PluginMethod
  public void alarm(PluginCall c) {
    int h = c.getInt("hour", 7), m = c.getInt("minute", 0);
    go(new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
        .putExtra(AlarmClock.EXTRA_MESSAGE, c.getString("label", "Ryza")).putExtra(AlarmClock.EXTRA_SKIP_UI, true));
    c.resolve();
  }

  @PluginMethod
  public void timer(PluginCall c) {
    int s = c.getInt("seconds", 60);
    go(new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s)
        .putExtra(AlarmClock.EXTRA_MESSAGE, c.getString("label", "Ryza")).putExtra(AlarmClock.EXTRA_SKIP_UI, true));
    c.resolve();
  }

  @PluginMethod
  public void openApp(PluginCall c) {
    PackageManager pm = getContext().getPackageManager();
    String want = c.getString("name", "").toLowerCase();
    Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
    for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
      String label = r.loadLabel(pm).toString();
      if (label.toLowerCase().contains(want)) {
        Intent i = pm.getLaunchIntentForPackage(r.activityInfo.packageName);
        if (i != null) { go(i); c.resolve(new JSObject().put("opened", label)); return; }
      }
    }
    c.reject("App not found");
  }

  @PluginMethod
  public void dial(PluginCall c) {
    go(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(c.getString("number", "")))));
    c.resolve();
  }

  @PluginMethod
  public void sms(PluginCall c) {
    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.getString("number", ""))));
    i.putExtra("sms_body", c.getString("body", ""));
    go(i);
    c.resolve();
  }

  @PluginMethod
  public void torch(PluginCall c) {
    try {
      CameraManager cm = (CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE);
      cm.setTorchMode(cm.getCameraIdList()[0], c.getBoolean("on", true));
      c.resolve();
    } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
  }

  @PluginMethod
  public void vibrate(PluginCall c) {
    int ms = c.getInt("ms", 500);
    Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
    else v.vibrate(ms);
    c.resolve();
  }

  @PluginMethod
  public void battery(PluginCall c) {
    Intent b = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    int lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
    int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
    c.resolve(new JSObject().put("percent", lv * 100 / sc).put("charging", st == 2 || st == 5));
  }

  @PluginMethod
  public void usageAccess(PluginCall c) {
    go(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
    c.resolve();
  }

  @PluginMethod
  public void screenTime(PluginCall c) {
    int m = ScreenTime.minutes(getContext());
    if (m < 0) c.resolve(new JSObject().put("granted", false));
    else c.resolve(new JSObject().put("granted", true).put("minutes", m));
  }

  @PluginMethod
  public void startBackground(PluginCall c) {
    getContext().getSharedPreferences("ryza", Context.MODE_PRIVATE).edit().putBoolean("on", true)
        .putString("voice", c.getString("voice", "mommy")).putString("lang", c.getString("lang", "en")).apply();
    ContextCompat.startForegroundService(getContext(), new Intent(getContext(), ScoldService.class));
    c.resolve();
  }

  @PluginMethod
  public void stopBackground(PluginCall c) {
    getContext().getSharedPreferences("ryza", Context.MODE_PRIVATE).edit().putBoolean("on", false).apply();
    getContext().stopService(new Intent(getContext(), ScoldService.class));
    c.resolve();
  }

  @PluginMethod
  public void ignoreBattery(PluginCall c) {
    go(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getContext().getPackageName())));
    c.resolve();
  }
}
