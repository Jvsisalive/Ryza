package com.ryza.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context c, Intent i) {
    if (c.getSharedPreferences("ryza", Context.MODE_PRIVATE).getBoolean("on", false))
      ContextCompat.startForegroundService(c, new Intent(c, ScoldService.class));
  }
}
