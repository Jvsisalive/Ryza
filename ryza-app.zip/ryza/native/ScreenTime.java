package com.ryza.app;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Process;
import java.util.Calendar;

public class ScreenTime {
  /** Minutes the screen has been on today, or -1 if usage access isn't granted. */
  public static int minutes(Context ctx) {
    AppOpsManager ao = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
    boolean ok = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName()) == AppOpsManager.MODE_ALLOWED;
    if (!ok) return -1;
    UsageStatsManager u = (UsageStatsManager) ctx.getSystemService(Context.USAGE_STATS_SERVICE);
    Calendar d = Calendar.getInstance();
    d.set(Calendar.HOUR_OF_DAY, 0); d.set(Calendar.MINUTE, 0); d.set(Calendar.SECOND, 0);
    long now = System.currentTimeMillis(), on = 0, last = -1;
    UsageEvents e = u.queryEvents(d.getTimeInMillis(), now);
    UsageEvents.Event ev = new UsageEvents.Event();
    while (e.hasNextEvent()) {
      e.getNextEvent(ev);
      int t = ev.getEventType();
      if (t == 15) last = ev.getTimeStamp();
      else if (t == 16 && last >= 0) { on += ev.getTimeStamp() - last; last = -1; }
    }
    if (last >= 0) on += now - last;
    return (int) (on / 60000);
  }
}
