package com.ryza.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import androidx.core.app.NotificationCompat;
import java.util.Locale;
import java.util.Random;

/** Runs in the background, fully offline: no internet or API needed. */
public class ScoldService extends Service {
  private static final String CH = "ryza_watch", CH2 = "ryza_scold";
  private final Handler h = new Handler(Looper.getMainLooper());
  private TextToSpeech tts;
  private boolean ttsReady = false;
  private final Runnable tick = new Runnable() {
    @Override public void run() { check(); h.postDelayed(this, 5 * 60 * 1000L); }
  };

  private static final String[] EN = {
    "Sweetheart, you've been on your phone for %h hours today. Put it down and rest your eyes, okay?",
    "%h hours already? That's enough for today. Go drink some water and stretch for me.",
    "I'm not angry, I'm just worried. %h hours on the screen is too much. Take a break, dear.",
    "Phone down, please. You've been scrolling for %h hours. Go outside or get some sleep."
  };
  private static final String[] JA = {
    "今日はもう%h時間もスマホを見てるよ。ちょっと休もうね。",
    "%h時間も画面を見てるの？目を休めて、お水を飲んでね。",
    "もう、心配になっちゃうよ。スマホを置いて、少し休んで。"
  };

  @Override
  public void onCreate() {
    super.onCreate();
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationManager nm = getSystemService(NotificationManager.class);
      nm.createNotificationChannel(new NotificationChannel(CH, "Ryza watching", NotificationManager.IMPORTANCE_MIN));
      nm.createNotificationChannel(new NotificationChannel(CH2, "Ryza scolds", NotificationManager.IMPORTANCE_HIGH));
    }
    Notification n = new NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("Ryza is watching over you").setOngoing(true).build();
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
    else startForeground(1, n);
    tts = new TextToSpeech(this, st -> ttsReady = (st == TextToSpeech.SUCCESS));
    h.post(tick);
  }

  private void check() {
    SharedPreferences p = getSharedPreferences("ryza", MODE_PRIVATE);
    if (!p.getBoolean("on", false)) { stopSelf(); return; }
    int min = ScreenTime.minutes(this);
    long now = System.currentTimeMillis();
    if (min < 360 || now - p.getLong("last", 0) < 2 * 3600 * 1000L) return;
    p.edit().putLong("last", now).apply();
    boolean ja = "ja".equals(p.getString("lang", "en")), anime = "anime".equals(p.getString("voice", "mommy"));
    String[] pool = ja ? JA : EN;
    String msg = pool[new Random().nextInt(pool.length)].replace("%h", String.format(Locale.US, "%.1f", min / 60f));
    Notification n = new NotificationCompat.Builder(this, CH2).setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("Ryza").setContentText(msg).setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
        .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();
    try { getSystemService(NotificationManager.class).notify(2, n); } catch (Exception ignored) {}
    if (ttsReady) {
      tts.setLanguage(ja ? Locale.JAPAN : Locale.US);
      tts.setPitch(anime ? 1.45f : 0.9f);
      tts.setSpeechRate(anime ? 1.05f : 0.85f);
      Bundle b = new Bundle();
      b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, anime ? 1f : 0.8f);
      tts.speak(msg, TextToSpeech.QUEUE_FLUSH, b, "scold");
    }
  }

  @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
  @Override public IBinder onBind(Intent i) { return null; }
  @Override public void onDestroy() {
    h.removeCallbacks(tick);
    if (tts != null) tts.shutdown();
    super.onDestroy();
  }
}
